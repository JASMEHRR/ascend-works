// ASCEND WORKS — Single Page Application
const ICONS = {
  arrowRight: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 12h14M12 5l7 7-7 7"/></svg>',
  check: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"/></svg>',
  plus: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 5v14M5 12h14"/></svg>',
  close: '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 6L6 18M6 6l12 12"/></svg>',
  message: '<svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z"/></svg>',
  layout: '<svg width="80" height="80" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1"><path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"/></svg>',
  chart: '<svg width="80" height="80" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1"><path d="M23 6l-9.5 9.5-5-5L1 18"/><path d="M17 6h6v6"/></svg>',
  globe: '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 014 10 15.3 15.3 0 01-4 10 15.3 15.3 0 01-4-10 15.3 15.3 0 014-10z"/></svg>',
  mail: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>',
  mapPin: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z"/><circle cx="12" cy="10" r="3"/></svg>',
  calendar: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>'
};

let currentPage = 'home';

function navigateTo(page) {
  if (!routes[page]) page = '404';
  currentPage = page;
  document.querySelectorAll('.nav-link').forEach(link => {
    link.classList.toggle('active', link.dataset.page === page);
  });
  const app = document.getElementById('app');
  app.innerHTML = routes[page]();
  window.scrollTo(0, 0);
  initScrollReveal();
  const titles = {
    home: 'ASCEND WORKS — AI Website Redesign & Business Automation',
    about: 'About — ASCEND WORKS',
    services: 'Services — ASCEND WORKS',
    portfolio: 'Portfolio — ASCEND WORKS',
    'case-studies': 'Case Studies — ASCEND WORKS',
    process: 'Process — ASCEND WORKS',
    pricing: 'Pricing — ASCEND WORKS',
    faq: 'FAQ — ASCEND WORKS',
    contact: 'Contact — ASCEND WORKS',
    privacy: 'Privacy Policy — ASCEND WORKS',
    terms: 'Terms of Service — ASCEND WORKS',
    cookies: 'Cookie Policy — ASCEND WORKS',
    404: 'Page Not Found — ASCEND WORKS'
  };
  document.title = titles[page] || 'ASCEND WORKS';
}

function initScrollReveal() {
  const reveals = document.querySelectorAll('.reveal');
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('visible');
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.1, rootMargin: '0px 0px -50px 0px' });
  reveals.forEach(el => observer.observe(el));
}

function initNavScroll() {
  const nav = document.getElementById('mainNav');
  window.addEventListener('scroll', () => {
    nav.classList.toggle('scrolled', window.scrollY > 50);
  });
}

function toggleMobileMenu() {
  document.getElementById('mobileMenu').classList.toggle('open');
}

function toggleFaq(el) {
  const item = el.closest('.faq-item');
  const wasOpen = item.classList.contains('open');
  document.querySelectorAll('.faq-item').forEach(i => i.classList.remove('open'));
  if (!wasOpen) item.classList.add('open');
}

function renderNav() {
  return `<nav class="nav" id="mainNav">
    <a href="#" class="nav-logo" onclick="navigateTo('home'); return false;">ASCEND<span>WORKS</span></a>
    <div class="nav-links">
      <button class="nav-link ${currentPage === 'home' ? 'active' : ''}" data-page="home" onclick="navigateTo('home')">Home</button>
      <button class="nav-link ${currentPage === 'about' ? 'active' : ''}" data-page="about" onclick="navigateTo('about')">About</button>
      <button class="nav-link ${currentPage === 'services' ? 'active' : ''}" data-page="services" onclick="navigateTo('services')">Services</button>
      <button class="nav-link ${currentPage === 'portfolio' ? 'active' : ''}" data-page="portfolio" onclick="navigateTo('portfolio')">Portfolio</button>
      <button class="nav-link ${currentPage === 'case-studies' ? 'active' : ''}" data-page="case-studies" onclick="navigateTo('case-studies')">Case Studies</button>
      <button class="nav-link ${currentPage === 'process' ? 'active' : ''}" data-page="process" onclick="navigateTo('process')">Process</button>
      <button class="nav-link ${currentPage === 'pricing' ? 'active' : ''}" data-page="pricing" onclick="navigateTo('pricing')">Pricing</button>
      <button class="nav-link ${currentPage === 'faq' ? 'active' : ''}" data-page="faq" onclick="navigateTo('faq')">FAQ</button>
      <button class="nav-link ${currentPage === 'contact' ? 'active' : ''}" data-page="contact" onclick="navigateTo('contact')">Contact</button>
      <button class="nav-cta" onclick="navigateTo('contact')">Book a Call</button>
    </div>
    <button class="nav-mobile-toggle" onclick="toggleMobileMenu()" aria-label="Toggle menu">
      <span></span><span></span><span></span>
    </button>
  </nav>
  <div class="mobile-menu" id="mobileMenu">
    <button class="mobile-menu-close" onclick="toggleMobileMenu()" aria-label="Close menu">${ICONS.close}</button>
    <button class="mobile-menu-link" onclick="navigateTo('home'); toggleMobileMenu()">Home</button>
    <button class="mobile-menu-link" onclick="navigateTo('about'); toggleMobileMenu()">About</button>
    <button class="mobile-menu-link" onclick="navigateTo('services'); toggleMobileMenu()">Services</button>
    <button class="mobile-menu-link" onclick="navigateTo('portfolio'); toggleMobileMenu()">Portfolio</button>
    <button class="mobile-menu-link" onclick="navigateTo('case-studies'); toggleMobileMenu()">Case Studies</button>
    <button class="mobile-menu-link" onclick="navigateTo('process'); toggleMobileMenu()">Process</button>
    <button class="mobile-menu-link" onclick="navigateTo('pricing'); toggleMobileMenu()">Pricing</button>
    <button class="mobile-menu-link" onclick="navigateTo('faq'); toggleMobileMenu()">FAQ</button>
    <button class="mobile-menu-link" onclick="navigateTo('contact'); toggleMobileMenu()">Contact</button>
  </div>`;
}

function renderFooter() {
  return `<footer class="footer">
    <div class="footer-grid">
      <div>
        <div class="footer-brand">ASCEND<span>WORKS</span></div>
        <p class="footer-desc">AI Website Redesign & Business Automation for local businesses that refuse to blend in.</p>
      </div>
      <div>
        <div class="footer-col-title">Company</div>
        <button class="footer-link" onclick="navigateTo('about')">About</button>
        <button class="footer-link" onclick="navigateTo('process')">Process</button>
        <button class="footer-link" onclick="navigateTo('case-studies')">Case Studies</button>
        <button class="footer-link" onclick="navigateTo('contact')">Contact</button>
      </div>
      <div>
        <div class="footer-col-title">Services</div>
        <button class="footer-link" onclick="navigateTo('services')">Website Redesign</button>
        <button class="footer-link" onclick="navigateTo('services')">AI Automation</button>
        <button class="footer-link" onclick="navigateTo('services')">SEO & Performance</button>
        <button class="footer-link" onclick="navigateTo('services')">CRM Integration</button>
      </div>
      <div>
        <div class="footer-col-title">Legal</div>
        <button class="footer-link" onclick="navigateTo('privacy')">Privacy Policy</button>
        <button class="footer-link" onclick="navigateTo('terms')">Terms of Service</button>
        <button class="footer-link" onclick="navigateTo('cookies')">Cookie Policy</button>
      </div>
    </div>
    <div class="footer-bottom">
      <span>&copy; ${new Date().getFullYear()} ASCEND WORKS. All rights reserved.</span>
      <span>Mohali, Punjab, India</span>
    </div>
  </footer>`;
}

function renderHome() {
  return `<div class="page active">
    <section class="hero">
      <div class="hero-badge"><div class="hero-badge-dot"></div><span>Now accepting new clients</span></div>
      <h1 class="hero-title">Your website is costing you<br><span class="gradient-text">customers every day.</span></h1>
      <p class="hero-subtitle">We redesign outdated websites and build AI-powered automation systems that turn visitors into revenue — for local businesses that refuse to blend in.</p>
      <div class="hero-cta-group">
        <button class="btn-primary" onclick="navigateTo('contact')">Start Your Redesign ${ICONS.arrowRight}</button>
        <button class="btn-secondary" onclick="navigateTo('portfolio')">View Our Work</button>
      </div>
      <div class="hero-stats">
        <div class="hero-stat"><div class="hero-stat-value">47%</div><div class="hero-stat-label">Avg. Revenue Increase</div></div>
        <div class="hero-stat"><div class="hero-stat-value">3.2x</div><div class="hero-stat-label">Lead Conversion Boost</div></div>
        <div class="hero-stat"><div class="hero-stat-value">&lt;2s</div><div class="hero-stat-label">Load Time Guarantee</div></div>
        <div class="hero-stat"><div class="hero-stat-value">100%</div><div class="hero-stat-label">Mobile Optimized</div></div>
      </div>
    </section>

    <section class="section">
      <div class="section-header">
        <div class="section-label">Why it matters</div>
        <h2 class="section-title">An outdated website is silent revenue loss.</h2>
        <p class="section-subtitle">Most local business websites were built 5+ years ago. They load slowly, look dated, and fail to convert. We fix that.</p>
      </div>
      <div class="card-grid">
        <div class="card reveal"><div class="card-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M12 2v20M17 5H9.5a3.5 3.5 0 000 7h5a3.5 3.5 0 010 7H6"/></svg></div><div class="card-title">Higher conversion rates</div><div class="card-desc">Modern design patterns and clear messaging guide visitors to take action. Our clients see an average 3.2x increase in qualified leads.</div></div>
        <div class="card reveal"><div class="card-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/></svg></div><div class="card-title">Faster load times</div><div class="card-desc">Every second of delay costs 7% of conversions. We build sub-2-second websites that keep visitors engaged and improve search rankings.</div></div>
        <div class="card reveal"><div class="card-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M21 16V8a2 2 0 00-1-1.73l-7-4a2 2 0 00-2 0l-7 4A2 2 0 003 8v8a2 2 0 001 1.73l7 4a2 2 0 002 0l7-4A2 2 0 0021 16z"/></svg></div><div class="card-title">AI automation</div><div class="card-desc">Stop losing leads to slow response times. Our AI systems handle inquiries, book appointments, and follow up — 24/7, without hiring staff.</div></div>
        <div class="card reveal"><div class="card-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg></div><div class="card-title">Premium perception</div><div class="card-desc">Your website is your first impression. A polished, modern presence signals quality and justifies premium pricing before you say a word.</div></div>
        <div class="card reveal"><div class="card-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><rect x="2" y="3" width="20" height="14" rx="2" ry="2"/><line x1="8" y1="21" x2="16" y2="21"/><line x1="12" y1="17" x2="12" y2="21"/></svg></div><div class="card-title">Built for mobile-first</div><div class="card-desc">Over 70% of local searches happen on phones. Every site we build is designed for thumbs, not just desktops.</div></div>
        <div class="card reveal"><div class="card-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M12 19l7-7 3 3-7 7-3-3z"/><path d="M18 13l-1.5-7.5L2 2l3.5 14.5L13 18l5-5z"/><path d="M2 2l7.586 7.586"/><circle cx="11" cy="11" r="2"/></svg></div><div class="card-title">SEO that ranks</div><div class="card-desc">Technical SEO, structured data, and local optimization built in from day one — not bolted on as an afterthought.</div></div>
      </div>
    </section>

    <section class="section">
      <div class="section-header">
        <div class="section-label">Transformation</div>
        <h2 class="section-title">See the difference.</h2>
        <p class="section-subtitle">Most local business websites look like they were built in 2012. Here's what happens when ASCEND WORKS takes over.</p>
      </div>
      <div class="comparison">
        <div class="comparison-card reveal">
          <div class="comparison-header"><div class="comparison-dot before"></div><span class="comparison-label">Before — Generic Template</span></div>
          <div class="comparison-body before">
            <div class="mock-site"><div class="mock-site-header"><div class="mock-site-header-dot"></div><div class="mock-site-header-dot"></div><div class="mock-site-header-dot"></div></div><div class="mock-site-hero"></div><div class="mock-site-grid"><div class="mock-site-grid-item"></div><div class="mock-site-grid-item"></div><div class="mock-site-grid-item"></div><div class="mock-site-grid-item"></div></div></div>
          </div>
        </div>
        <div class="comparison-card reveal">
          <div class="comparison-header"><div class="comparison-dot after"></div><span class="comparison-label">After — ASCEND WORKS</span></div>
          <div class="comparison-body after">
            <div class="mock-site mock-site-modern"><div class="mock-site-header"><div class="mock-site-header-dot"></div><div class="mock-site-header-dot"></div><div class="mock-site-header-dot"></div></div><div class="mock-site-hero"></div><div class="mock-site-grid"><div class="mock-site-grid-item"></div><div class="mock-site-grid-item"></div><div class="mock-site-grid-item"></div><div class="mock-site-grid-item"></div></div></div>
          </div>
        </div>
      </div>
    </section>

    <section class="section">
      <div class="section-header"><div class="section-label">How we work</div><h2 class="section-title">Three steps to a better business.</h2></div>
      <div class="process-steps">
        <div class="process-step reveal"><div class="process-number">01</div><div class="process-content"><div class="process-title">Discovery & Audit</div><div class="process-desc">We analyze your current site, competitors, and customer journey. Within 48 hours, you receive a detailed audit with specific recommendations and a clear roadmap.</div></div></div>
        <div class="process-step reveal"><div class="process-number">02</div><div class="process-content"><div class="process-title">Design & Build</div><div class="process-desc">Our team redesigns your site from the ground up — custom design, premium copywriting, AI automation setup, and performance optimization. You review and approve every step.</div></div></div>
        <div class="process-step reveal"><div class="process-number">03</div><div class="process-content"><div class="process-title">Launch & Scale</div><div class="process-desc">We launch your new site, set up analytics, and monitor performance. Most clients see measurable results within the first 30 days. We stay on for ongoing optimization.</div></div></div>
      </div>
    </section>

    <section class="section">
      <div class="section-header"><div class="section-label">Featured work</div><h2 class="section-title">Projects that speak for themselves.</h2><p class="section-subtitle">Demo projects showcasing our capabilities across industries.</p></div>
      <div class="portfolio-grid">
        <div class="portfolio-card reveal" onclick="navigateTo('portfolio')"><div class="portfolio-img-wrap"><img class="portfolio-img" src="https://images.unsplash.com/photo-1629909613654-28e377c37b09?w=800&q=80" alt="Dental Practice" loading="lazy"><div class="portfolio-demo-badge">Demo Project</div><div class="portfolio-overlay"><span class="btn-primary" style="font-size:0.875rem;padding:0.5rem 1rem;">View Project</span></div></div><div class="portfolio-info"><div class="portfolio-tag">Medical / Dental</div><div class="portfolio-title">SmileCraft Dental</div><div class="portfolio-desc">Complete redesign with online booking and AI chatbot.</div></div></div>
        <div class="portfolio-card reveal" onclick="navigateTo('portfolio')"><div class="portfolio-img-wrap"><img class="portfolio-img" src="https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=800&q=80" alt="Real Estate" loading="lazy"><div class="portfolio-demo-badge">Demo Project</div><div class="portfolio-overlay"><span class="btn-primary" style="font-size:0.875rem;padding:0.5rem 1rem;">View Project</span></div></div><div class="portfolio-info"><div class="portfolio-tag">Real Estate</div><div class="portfolio-title">Meridian Properties</div><div class="portfolio-desc">Luxury listing platform with CRM integration and lead automation.</div></div></div>
        <div class="portfolio-card reveal" onclick="navigateTo('portfolio')"><div class="portfolio-img-wrap"><img class="portfolio-img" src="https://images.unsplash.com/photo-1581094794329-c8112a89af12?w=800&q=80" alt="Construction" loading="lazy"><div class="portfolio-demo-badge">Demo Project</div><div class="portfolio-overlay"><span class="btn-primary" style="font-size:0.875rem;padding:0.5rem 1rem;">View Project</span></div></div><div class="portfolio-info"><div class="portfolio-tag">Construction</div><div class="portfolio-title">Apex Build Group</div><div class="portfolio-desc">Industrial brand presence with project portfolio and quote automation.</div></div></div>
      </div>
    </section>

    <section class="section">
      <div class="section-header"><div class="section-label">Testimonials</div><h2 class="section-title">What clients say.</h2></div>
      <div class="testimonial-grid">
        <div class="testimonial-placeholder reveal">${ICONS.message}<p class="testimonial-placeholder-text">Client testimonials will appear here.<br>Currently accepting reviews from first clients.</p></div>
        <div class="testimonial-placeholder reveal">${ICONS.message}<p class="testimonial-placeholder-text">Placeholder for future client feedback.<br>Reviews updated after each completed project.</p></div>
        <div class="testimonial-placeholder reveal">${ICONS.message}<p class="testimonial-placeholder-text">Your testimonial could be here.<br>Join our growing list of satisfied clients.</p></div>
      </div>
    </section>

    <section class="section">
      <div class="section-header"><div class="section-label">FAQ</div><h2 class="section-title">Common questions.</h2></div>
      <div class="faq-list">
        <div class="faq-item reveal"><button class="faq-question" onclick="toggleFaq(this)"><span>How long does a typical redesign take?</span>${ICONS.plus}</button><div class="faq-answer">Most projects launch within 2–4 weeks from kickoff. Complex builds with custom automation may take 6–8 weeks. We always provide a detailed timeline before starting.</div></div>
        <div class="faq-item reveal"><button class="faq-question" onclick="toggleFaq(this)"><span>Do you work with businesses outside India?</span>${ICONS.plus}</button><div class="faq-answer">Yes. While we're based in Mohali, Punjab, we serve clients globally. All meetings happen over video call, and we work across time zones.</div></div>
        <div class="faq-item reveal"><button class="faq-question" onclick="toggleFaq(this)"><span>What industries do you specialize in?</span>${ICONS.plus}</button><div class="faq-answer">Medical, dental, legal, construction, real estate, home services, and luxury businesses. We understand the unique needs of local service businesses.</div></div>
        <div class="faq-item reveal"><button class="faq-question" onclick="toggleFaq(this)"><span>Will my new site be easy to update?</span>${ICONS.plus}</button><div class="faq-answer">Absolutely. We build on modern, user-friendly platforms. You'll get training and documentation. Most clients update content without touching code.</div></div>
        <div class="faq-item reveal"><button class="faq-question" onclick="toggleFaq(this)"><span>What's included in the AI automation?</span>${ICONS.plus}</button><div class="faq-answer">Lead capture, instant response chatbots, appointment booking, follow-up sequences, and CRM integration. We tailor the stack to your specific workflow.</div></div>
      </div>
    </section>

    <div class="cta-banner">
      <h2 class="cta-banner-title">Ready to stop losing customers to a bad website?</h2>
      <p class="cta-banner-subtitle">Book a free 15-minute audit. We'll show you exactly what's wrong and how to fix it.</p>
      <button class="btn-primary" onclick="navigateTo('contact')" style="font-size:1rem;padding:1rem 2.5rem;">Book Your Free Audit</button>
    </div>
  </div>${renderFooter()}`;
}

// ABOUT PAGE
function renderAbout() {
  return `<div class="page active">
    <section class="about-hero">
      <div class="section-label">About us</div>
      <h1 class="about-hero-title">Built for businesses that<br>refuse to blend in.</h1>
      <p class="about-hero-subtitle">ASCEND WORKS exists because most local business websites are invisible. We change that.</p>
    </section>
    <section class="section">
      <div class="about-story">
        <div class="about-story-visual reveal"><div class="about-story-visual-inner">${ICONS.layout}</div></div>
        <div class="about-story-content reveal">
          <h3>Why we exist</h3>
          <p>Most local businesses — dentists, lawyers, contractors, real estate agents — have websites that look like they were built a decade ago. Slow. Cluttered. Confusing. They don't reflect the quality of the actual business.</p>
          <p>We started ASCEND WORKS to fix this gap. Not with templates. Not with cheap shortcuts. With thoughtful, conversion-focused design that makes visitors trust you before they ever pick up the phone.</p>
          <p>Our mission is simple: help local businesses increase revenue by redesigning outdated websites and building AI-powered automation systems that work while you sleep.</p>
        </div>
      </div>
    </section>
    <section class="section">
      <div class="section-header"><div class="section-label">The advantage</div><h2 class="section-title">Why AI changes everything.</h2></div>
      <div class="card-grid">
        <div class="card reveal"><div class="card-title">Faster delivery</div><div class="card-desc">AI-assisted design and development means we deliver premium results in weeks, not months. What used to take a team of five now takes our tight, focused crew.</div></div>
        <div class="card reveal"><div class="card-title">Better copy</div><div class="card-desc">We use AI to research your industry, analyze competitors, and write conversion-focused copy that speaks directly to your ideal customer's pain points.</div></div>
        <div class="card reveal"><div class="card-title">Smarter automation</div><div class="card-desc">AI chatbots, lead scoring, and automated follow-ups mean no inquiry goes cold. Your business responds instantly, even at 2 AM.</div></div>
        <div class="card reveal"><div class="card-title">Continuous optimization</div><div class="card-desc">We analyze real visitor behavior and use AI insights to continuously improve your site. It's not a one-and-done project — it's a growth engine.</div></div>
      </div>
    </section>
    <section class="section">
      <div class="section-header"><div class="section-label">The impact</div><h2 class="section-title">Modern websites increase revenue.</h2></div>
      <div class="about-story" style="direction:rtl;">
        <div class="about-story-visual reveal" style="direction:ltr;"><div class="about-story-visual-inner">${ICONS.chart}</div></div>
        <div class="about-story-content reveal" style="direction:ltr;">
          <h3>The data doesn't lie</h3>
          <p>75% of consumers admit to making judgments on a company's credibility based on their website design. A slow, outdated site doesn't just look bad — it actively drives customers to your competitors.</p>
          <p>A 1-second improvement in load time can increase conversions by 7%. A modern, mobile-optimized design can increase mobile conversions by up to 200%. These aren't vanity metrics — they're revenue.</p>
          <p>We don't build websites to win design awards (though they might). We build websites that make the phone ring, the inbox fill, and the calendar book solid.</p>
        </div>
      </div>
    </section>
  </div>${renderFooter()}`;
}

// SERVICES PAGE
function renderServices() {
  return `<div class="page active">
    <section class="services-hero">
      <div class="section-label">Services</div>
      <h1 class="services-hero-title">Everything you need to<br>win online.</h1>
      <p class="section-subtitle" style="max-width:600px;margin:1rem auto 0;">From redesign to revenue. A complete digital transformation stack for local businesses.</p>
    </section>
    <section class="section">
      <div class="services-grid">
        <div class="service-card-large reveal"><div class="card-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"/><line x1="3" y1="9" x2="21" y2="9"/><line x1="9" y1="21" x2="9" y2="9"/></svg></div><div class="card-title">Website Redesign</div><div class="card-desc">Complete overhaul of your existing site. Modern design, faster load times, mobile optimization, and conversion-focused layouts.</div><ul class="service-list"><li>${ICONS.check}Custom design (no templates)</li><li>${ICONS.check}Sub-2-second load guarantee</li><li>${ICONS.check}Mobile-first responsive</li><li>${ICONS.check}Accessibility compliant (WCAG)</li></ul></div>
        <div class="service-card-large reveal"><div class="card-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/><polyline points="10 9 9 9 8 9"/></svg></div><div class="card-title">Landing Pages</div><div class="card-desc">High-converting single-page experiences designed for specific campaigns, services, or offers. Built to turn traffic into leads.</div><ul class="service-list"><li>${ICONS.check}A/B tested layouts</li><li>${ICONS.check}Form optimization</li><li>${ICONS.check}Analytics integration</li><li>${ICONS.check}Fast turnaround (1 week)</li></ul></div>
        <div class="service-card-large reveal"><div class="card-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><rect x="2" y="3" width="20" height="14" rx="2" ry="2"/><line x1="8" y1="21" x2="16" y2="21"/><line x1="12" y1="17" x2="12" y2="21"/></svg></div><div class="card-title">Business Websites</div><div class="card-desc">Full multi-page websites for established businesses. Service pages, about, contact, blog, and everything in between.</div><ul class="service-list"><li>${ICONS.check}5-15 pages included</li><li>${ICONS.check}CMS integration</li><li>${ICONS.check}Blog setup</li><li>${ICONS.check}Multi-location support</li></ul></div>
        <div class="service-card-large reveal"><div class="card-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M21 16V8a2 2 0 00-1-1.73l-7-4a2 2 0 00-2 0l-7 4A2 2 0 003 8v8a2 2 0 001 1.73l7 4a2 2 0 002 0l7-4A2 2 0 0021 16z"/></svg></div><div class="card-title">AI Automation</div><div class="card-desc">Intelligent systems that handle inquiries, qualify leads, book appointments, and follow up — without human intervention.</div><ul class="service-list"><li>${ICONS.check}AI chatbot integration</li><li>${ICONS.check}Lead qualification</li><li>${ICONS.check}Automated follow-ups</li><li>${ICONS.check}24/7 availability</li></ul></div>
        <div class="service-card-large reveal"><div class="card-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07 19.5 19.5 0 01-6-6 19.79 19.79 0 01-3.07-8.67A2 2 0 014.11 2h3a2 2 0 012 1.72c.127.96.361 1.903.7 2.81a2 2 0 01-.45 2.11L8.09 9.91a16 16 0 006 6l1.27-1.27a2 2 0 012.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0122 16.92z"/></svg></div><div class="card-title">Lead Generation</div><div class="card-desc">Strategic funnels and capture mechanisms designed to turn casual visitors into qualified prospects ready to buy.</div><ul class="service-list"><li>${ICONS.check}Lead magnet creation</li><li>${ICONS.check}Form optimization</li><li>${ICONS.check}Retargeting setup</li><li>${ICONS.check}Conversion tracking</li></ul></div>
        <div class="service-card-large reveal"><div class="card-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><circle cx="11" cy="11" r="8"/><path d="M21 21l-4.35-4.35"/></svg></div><div class="card-title">SEO & Performance</div><div class="card-desc">Technical SEO, on-page optimization, and performance tuning that gets you found and keeps visitors engaged.</div><ul class="service-list"><li>${ICONS.check}Technical SEO audit</li><li>${ICONS.check}Local SEO optimization</li><li>${ICONS.check}Core Web Vitals tuning</li><li>${ICONS.check}Structured data markup</li></ul></div>
        <div class="service-card-large reveal"><div class="card-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M14.7 6.3a1 1 0 000 1.4l1.6 1.6a1 1 0 001.4 0l3.77-3.77a6 6 0 01-7.94 7.94l-6.91 6.91a2.12 2.12 0 01-3-3l6.91-6.91a6 6 0 017.94-7.94l-3.76 3.76z"/></svg></div><div class="card-title">Website Audits</div><div class="card-desc">Comprehensive analysis of your current site with actionable recommendations. Know exactly what's broken and how to fix it.</div><ul class="service-list"><li>${ICONS.check}Performance analysis</li><li>${ICONS.check}UX review</li><li>${ICONS.check}SEO health check</li><li>${ICONS.check}Competitor comparison</li></ul></div>
        <div class="service-card-large reveal"><div class="card-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 00-3-3.87M16 3.13a4 4 0 010 7.75"/></svg></div><div class="card-title">CRM Integration</div><div class="card-desc">Connect your website to your CRM for seamless lead management. No more manual data entry or lost inquiries.</div><ul class="service-list"><li>${ICONS.check}HubSpot, Salesforce, Zoho</li><li>${ICONS.check}Lead scoring setup</li><li>${ICONS.check}Pipeline automation</li><li>${ICONS.check}Custom workflows</li></ul></div>
        <div class="service-card-large reveal"><div class="card-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg></div><div class="card-title">Appointment Booking</div><div class="card-desc">Custom booking systems that integrate with your calendar, send reminders, and reduce no-shows automatically.</div><ul class="service-list"><li>${ICONS.check}Calendar integration</li><li>${ICONS.check}Automated reminders</li><li>${ICONS.check}Payment collection</li><li>${ICONS.check}Rescheduling portal</li></ul></div>
      </div>
    </section>
  </div>${renderFooter()}`;
}

// PORTFOLIO PAGE
function renderPortfolio() {
  return `<div class="page active">
    <section class="about-hero">
      <div class="section-label">Portfolio</div>
      <h1 class="about-hero-title">Work that speaks<br>for itself.</h1>
      <p class="about-hero-subtitle">Demo projects showcasing our design and development capabilities. Real client work coming soon.</p>
    </section>
    <section class="section">
      <div class="portfolio-grid">
        <div class="portfolio-card reveal"><div class="portfolio-img-wrap"><img class="portfolio-img" src="https://images.unsplash.com/photo-1629909613654-28e377c37b09?w=800&q=80" alt="Dental Practice" loading="lazy"><div class="portfolio-demo-badge">Demo Project</div></div><div class="portfolio-info"><div class="portfolio-tag">Medical / Dental</div><div class="portfolio-title">SmileCraft Dental</div><div class="portfolio-desc">Complete redesign with online booking and AI chatbot. Focus on patient trust and appointment conversion.</div></div></div>
        <div class="portfolio-card reveal"><div class="portfolio-img-wrap"><img class="portfolio-img" src="https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=800&q=80" alt="Real Estate" loading="lazy"><div class="portfolio-demo-badge">Demo Project</div></div><div class="portfolio-info"><div class="portfolio-tag">Real Estate</div><div class="portfolio-title">Meridian Properties</div><div class="portfolio-desc">Luxury listing platform with CRM integration and lead automation. High-end visual experience.</div></div></div>
        <div class="portfolio-card reveal"><div class="portfolio-img-wrap"><img class="portfolio-img" src="https://images.unsplash.com/photo-1581094794329-c8112a89af12?w=800&q=80" alt="Construction" loading="lazy"><div class="portfolio-demo-badge">Demo Project</div></div><div class="portfolio-info"><div class="portfolio-tag">Construction</div><div class="portfolio-title">Apex Build Group</div><div class="portfolio-desc">Industrial brand presence with project portfolio and quote automation. Built for B2B trust.</div></div></div>
        <div class="portfolio-card reveal"><div class="portfolio-img-wrap"><img class="portfolio-img" src="https://images.unsplash.com/photo-1576091160550-2173dba999ef?w=800&q=80" alt="Medical Clinic" loading="lazy"><div class="portfolio-demo-badge">Demo Project</div></div><div class="portfolio-info"><div class="portfolio-tag">Medical</div><div class="portfolio-title">Vitality Health Clinic</div><div class="portfolio-desc">Patient portal, service listings, and automated appointment scheduling for a multi-doctor practice.</div></div></div>
        <div class="portfolio-card reveal"><div class="portfolio-img-wrap"><img class="portfolio-img" src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=800&q=80" alt="Law Firm" loading="lazy"><div class="portfolio-demo-badge">Demo Project</div></div><div class="portfolio-info"><div class="portfolio-tag">Legal</div><div class="portfolio-title">Harrison & Associates</div><div class="portfolio-desc">Professional law firm presence with case intake forms, attorney profiles, and consultation booking.</div></div></div>
        <div class="portfolio-card reveal"><div class="portfolio-img-wrap"><img class="portfolio-img" src="https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?w=800&q=80" alt="Luxury Home" loading="lazy"><div class="portfolio-demo-badge">Demo Project</div></div><div class="portfolio-info"><div class="portfolio-tag">Luxury / Home Services</div><div class="portfolio-title">Luxe Living Interiors</div><div class="portfolio-desc">High-end interior design portfolio with immersive galleries and client inquiry automation.</div></div></div>
      </div>
    </section>
    <div class="cta-banner">
      <h2 class="cta-banner-title">Want your project featured here?</h2>
      <p class="cta-banner-subtitle">Let's build something worth showing off.</p>
      <button class="btn-primary" onclick="navigateTo('contact')" style="font-size:1rem;padding:1rem 2.5rem;">Start Your Project</button>
    </div>
  </div>${renderFooter()}`;
}

// CASE STUDIES PAGE
function renderCaseStudies() {
  return `<div class="page active">
    <section class="about-hero">
      <div class="section-label">Case Studies</div>
      <h1 class="about-hero-title">Real results,<br>real businesses.</h1>
      <p class="about-hero-subtitle">Editable case study templates. Replace placeholders with your actual client results as you complete projects.</p>
    </section>
    <section class="section">
      <div class="card-grid" style="grid-template-columns:1fr;">
        <div class="case-study-card reveal">
          <div class="case-study-header"><span class="case-study-tag">Medical / Dental</span><h3 class="case-study-title">SmileCraft Dental — Complete Digital Overhaul</h3><p class="case-study-meta">Duration: 3 weeks | Services: Redesign, AI Chatbot, Booking System</p></div>
          <div class="case-study-body">
            <div class="case-study-section"><div class="case-study-section-title">Challenge</div><p class="case-study-section-text">SmileCraft's 8-year-old website was loading in 6+ seconds, had no mobile optimization, and was losing 40% of potential patients at the contact form. Their booking process required three phone calls.</p></div>
            <div class="case-study-section"><div class="case-study-section-title">Solution</div><p class="case-study-section-text">Complete redesign with mobile-first approach, integrated AI chatbot for 24/7 patient inquiries, and direct calendar booking that syncs with their practice management software.</p></div>
            <div class="case-study-section"><div class="case-study-section-title">Process</div><p class="case-study-section-text">Week 1: Discovery, competitor analysis, and wireframes. Week 2: Visual design, copywriting, and chatbot training. Week 3: Development, testing, and launch with analytics setup.</p></div>
          </div>
          <div class="case-study-metrics">
            <div class="case-study-metric"><div class="case-study-metric-value placeholder">[TBD]</div><div class="case-study-metric-label">Conversion Rate Increase</div></div>
            <div class="case-study-metric"><div class="case-study-metric-value placeholder">[TBD]</div><div class="case-study-metric-label">Load Time Improvement</div></div>
            <div class="case-study-metric"><div class="case-study-metric-value placeholder">[TBD]</div><div class="case-study-metric-label">New Monthly Leads</div></div>
          </div>
        </div>
        <div class="case-study-card reveal">
          <div class="case-study-header"><span class="case-study-tag">Real Estate</span><h3 class="case-study-title">Meridian Properties — Luxury Listing Platform</h3><p class="case-study-meta">Duration: 5 weeks | Services: Custom Build, CRM Integration, Lead Automation</p></div>
          <div class="case-study-body">
            <div class="case-study-section"><div class="case-study-section-title">Challenge</div><p class="case-study-section-text">Meridian was using a generic property template that didn't reflect their luxury positioning. Leads were going cold because response times averaged 6 hours. No integration with their existing CRM.</p></div>
            <div class="case-study-section"><div class="case-study-section-title">Solution</div><p class="case-study-section-text">Custom-built property platform with immersive galleries, automated lead qualification, instant property alerts, and two-way CRM sync. Every inquiry triggers an immediate personalized response.</p></div>
            <div class="case-study-section"><div class="case-study-section-title">Process</div><p class="case-study-section-text">Two-week design phase with luxury brand positioning. Three-week build with custom property CMS, CRM webhook integration, and automated email sequences. One week of testing and team training.</p></div>
          </div>
          <div class="case-study-metrics">
            <div class="case-study-metric"><div class="case-study-metric-value placeholder">[TBD]</div><div class="case-study-metric-label">Lead Response Time</div></div>
            <div class="case-study-metric"><div class="case-study-metric-value placeholder">[TBD]</div><div class="case-study-metric-label">Qualified Leads / Month</div></div>
            <div class="case-study-metric"><div class="case-study-metric-value placeholder">[TBD]</div><div class="case-study-metric-label">Revenue Impact</div></div>
          </div>
        </div>
        <div class="case-study-card reveal">
          <div class="case-study-header"><span class="case-study-tag">Construction</span><h3 class="case-study-title">Apex Build Group — B2B Lead Generation</h3><p class="case-study-meta">Duration: 4 weeks | Services: Redesign, SEO, Quote Automation</p></div>
          <div class="case-study-body">
            <div class="case-study-section"><div class="case-study-section-title">Challenge</div><p class="case-study-section-text">Apex relied entirely on referrals and word-of-mouth. Their website was a single page with a phone number. They had no digital presence for commercial project inquiries and were losing RFP opportunities.</p></div>
            <div class="case-study-section"><div class="case-study-section-title">Solution</div><p class="case-study-section-text">Multi-page commercial presence with project portfolio, automated quote request system, and SEO targeting commercial construction keywords in their service area.</p></div>
            <div class="case-study-section"><div class="case-study-section-title">Process</div><p class="case-study-section-text">Discovery of their ideal project types and client profiles. Portfolio curation and case study development. Custom quote calculator with automated PDF generation and CRM logging.</p></div>
          </div>
          <div class="case-study-metrics">
            <div class="case-study-metric"><div class="case-study-metric-value placeholder">[TBD]</div><div class="case-study-metric-label">Organic Traffic Growth</div></div>
            <div class="case-study-metric"><div class="case-study-metric-value placeholder">[TBD]</div><div class="case-study-metric-label">Quote Requests / Month</div></div>
            <div class="case-study-metric"><div class="case-study-metric-value placeholder">[TBD]</div><div class="case-study-metric-label">Project Win Rate</div></div>
          </div>
        </div>
      </div>
    </section>
  </div>${renderFooter()}`;
}

// PROCESS PAGE
function renderProcess() {
  return `<div class="page active">
    <section class="about-hero">
      <div class="section-label">Process</div>
      <h1 class="about-hero-title">How we build<br>better businesses.</h1>
      <p class="about-hero-subtitle">A proven, transparent process designed to minimize risk and maximize results.</p>
    </section>
    <section class="section">
      <div class="process-steps">
        <div class="process-step reveal"><div class="process-number">01</div><div class="process-content"><div class="process-title">Discovery & Strategy</div><div class="process-desc">We start with a deep dive into your business, competitors, and customers. We audit your current site, analyze your market position, and identify the highest-impact opportunities. You receive a detailed strategy document with clear priorities and expected outcomes.</div></div></div>
        <div class="process-step reveal"><div class="process-number">02</div><div class="process-content"><div class="process-title">Design & Prototyping</div><div class="process-desc">Every pixel is intentional. We create wireframes, then high-fidelity designs for every page. You'll see exactly how your site will look and feel before we write a single line of code. Two rounds of revisions are included.</div></div></div>
        <div class="process-step reveal"><div class="process-number">03</div><div class="process-content"><div class="process-title">Development & Automation</div><div class="process-desc">We build your site with clean, maintainable code. Simultaneously, we configure your AI automation, CRM integrations, and booking systems. Everything is tested across devices and browsers.</div></div></div>
        <div class="process-step reveal"><div class="process-number">04</div><div class="process-content"><div class="process-title">Content & SEO Setup</div><div class="process-desc">We write or optimize all copy for conversion and search. Technical SEO, structured data, local business markup, and analytics are configured. Your site is built to be found.</div></div></div>
        <div class="process-step reveal"><div class="process-number">05</div><div class="process-content"><div class="process-title">Launch & Optimization</div><div class="process-desc">We handle the launch, domain setup, and SSL configuration. Post-launch, we monitor performance for 30 days and make optimization adjustments. You get training and documentation for ongoing management.</div></div></div>
      </div>
    </section>
  </div>${renderFooter()}`;
}

// PRICING PAGE
function renderPricing() {
  return `<div class="page active">
    <section class="about-hero">
      <div class="section-label">Pricing</div>
      <h1 class="about-hero-title">Simple, transparent<br>pricing.</h1>
      <p class="about-hero-subtitle">No hidden fees. No surprises. Choose the package that fits your stage.</p>
    </section>
    <section class="section">
      <div class="pricing-grid">
        <div class="pricing-card reveal">
          <div class="pricing-name">Starter</div><div class="pricing-desc">Perfect for small businesses ready for a professional online presence.</div>
          <div class="pricing-price">INR 49,999</div><div class="pricing-period">one-time payment</div>
          <ul class="pricing-features"><li>${ICONS.check}Single-page website</li><li>${ICONS.check}Mobile responsive</li><li>${ICONS.check}Basic SEO setup</li><li>${ICONS.check}Contact form</li><li>${ICONS.check}2 weeks delivery</li><li>${ICONS.check}30 days support</li></ul>
          <button class="btn-secondary" style="width:100%;" onclick="navigateTo('contact')">Get Started</button>
        </div>
        <div class="pricing-card featured reveal">
          <div class="pricing-name">Growth</div><div class="pricing-desc">For established businesses ready to scale leads and automate operations.</div>
          <div class="pricing-price">INR 1,49,999</div><div class="pricing-period">one-time payment</div>
          <ul class="pricing-features"><li>${ICONS.check}Up to 10 pages</li><li>${ICONS.check}AI chatbot integration</li><li>${ICONS.check}CRM integration</li><li>${ICONS.check}Advanced SEO & analytics</li><li>${ICONS.check}Blog setup</li><li>${ICONS.check}4 weeks delivery</li><li>${ICONS.check}90 days support</li></ul>
          <button class="btn-primary" style="width:100%;" onclick="navigateTo('contact')">Get Started</button>
        </div>
        <div class="pricing-card reveal">
          <div class="pricing-name">Enterprise</div><div class="pricing-desc">Custom solutions for multi-location businesses and complex requirements.</div>
          <div class="pricing-price">Custom</div><div class="pricing-period">tailored to scope</div>
          <ul class="pricing-features"><li>${ICONS.check}Unlimited pages</li><li>${ICONS.check}Custom automation workflows</li><li>${ICONS.check}Multi-location support</li><li>${ICONS.check}Priority support</li><li>${ICONS.check}Dedicated account manager</li><li>${ICONS.check}Ongoing optimization</li><li>${ICONS.check}Custom integrations</li></ul>
          <button class="btn-secondary" style="width:100%;" onclick="navigateTo('contact')">Contact Us</button>
        </div>
      </div>
    </section>
    <div class="cta-banner">
      <h2 class="cta-banner-title">Not sure which plan is right?</h2>
      <p class="cta-banner-subtitle">Book a free audit and we'll recommend the best approach for your specific situation.</p>
      <button class="btn-primary" onclick="navigateTo('contact')" style="font-size:1rem;padding:1rem 2.5rem;">Book Free Audit</button>
    </div>
  </div>${renderFooter()}`;
}

// FAQ PAGE
function renderFAQ() {
  return `<div class="page active">
    <section class="about-hero">
      <div class="section-label">FAQ</div>
      <h1 class="about-hero-title">Questions?<br>We've got answers.</h1>
      <p class="about-hero-subtitle">Everything you need to know before starting your project.</p>
    </section>
    <section class="section">
      <div class="faq-list">
        <div class="faq-item reveal"><button class="faq-question" onclick="toggleFaq(this)"><span>How long does a typical redesign take?</span>${ICONS.plus}</button><div class="faq-answer">Most projects launch within 2–4 weeks from kickoff. Complex builds with custom automation may take 6–8 weeks. We always provide a detailed timeline before starting.</div></div>
        <div class="faq-item reveal"><button class="faq-question" onclick="toggleFaq(this)"><span>Do you work with businesses outside India?</span>${ICONS.plus}</button><div class="faq-answer">Yes. While we're based in Mohali, Punjab, we serve clients globally. All meetings happen over video call, and we work across time zones.</div></div>
        <div class="faq-item reveal"><button class="faq-question" onclick="toggleFaq(this)"><span>What industries do you specialize in?</span>${ICONS.plus}</button><div class="faq-answer">Medical, dental, legal, construction, real estate, home services, and luxury businesses. We understand the unique needs of local service businesses.</div></div>
        <div class="faq-item reveal"><button class="faq-question" onclick="toggleFaq(this)"><span>Will my new site be easy to update?</span>${ICONS.plus}</button><div class="faq-answer">Absolutely. We build on modern, user-friendly platforms. You'll get training and documentation. Most clients update content without touching code.</div></div>
        <div class="faq-item reveal"><button class="faq-question" onclick="toggleFaq(this)"><span>What's included in the AI automation?</span>${ICONS.plus}</button><div class="faq-answer">Lead capture, instant response chatbots, appointment booking, follow-up sequences, and CRM integration. We tailor the stack to your specific workflow.</div></div>
        <div class="faq-item reveal"><button class="faq-question" onclick="toggleFaq(this)"><span>What happens after the site launches?</span>${ICONS.plus}</button><div class="faq-answer">We monitor performance for 30 days and make optimization adjustments. After that, we offer monthly maintenance and optimization retainers to keep your site performing at its peak.</div></div>
        <div class="faq-item reveal"><button class="faq-question" onclick="toggleFaq(this)"><span>Do you offer payment plans?</span>${ICONS.plus}</button><div class="faq-answer">Yes. For projects over INR 1,00,000, we offer a 50/50 split: 50% to start, 50% on launch. Enterprise projects can be structured in milestone-based payments.</div></div>
        <div class="faq-item reveal"><button class="faq-question" onclick="toggleFaq(this)"><span>Can you work with my existing brand?</span>${ICONS.plus}</button><div class="faq-answer">Absolutely. We'll refine and elevate your existing brand for digital, or work within your established guidelines. We also offer full rebranding services if needed.</div></div>
      </div>
    </section>
  </div>${renderFooter()}`;
}

// CONTACT PAGE
function renderContact() {
  return `<div class="page active">
    <section class="about-hero">
      <div class="section-label">Contact</div>
      <h1 class="about-hero-title">Let's build something<br>great together.</h1>
      <p class="about-hero-subtitle">Book a free 15-minute audit or send us a message. We respond within 24 hours.</p>
    </section>
    <section class="section">
      <div class="contact-grid">
        <div class="contact-info reveal">
          <h3>Get in touch</h3>
          <p>Whether you're ready to start or just exploring options, we'd love to hear from you. Every project begins with a conversation.</p>
          <div class="contact-detail"><div class="contact-detail-icon">${ICONS.mapPin}</div><div class="contact-detail-text">Mohali, Punjab, India</div></div>
          <div class="contact-detail"><div class="contact-detail-icon">${ICONS.mail}</div><div class="contact-detail-text">[your-email@ascendworks.in]</div></div>
          <div class="contact-detail"><div class="contact-detail-icon">${ICONS.calendar}</div><div class="contact-detail-text"><a href="#" style="color:var(--text-secondary);">Book via Google Form (placeholder)</a></div></div>
          <div style="margin-top:2rem;padding:1.5rem;border:1px solid var(--border);border-radius:12px;background:rgba(255,255,255,0.02);">
            <div style="font-size:0.875rem;font-weight:600;margin-bottom:0.5rem;">Prefer to book directly?</div>
            <div style="font-size:0.875rem;color:var(--text-secondary);margin-bottom:1rem;">Use our scheduling link to pick a time that works for you.</div>
            <button class="btn-secondary" style="font-size:0.875rem;padding:0.625rem 1.25rem;">Google Calendar Booking (placeholder)</button>
          </div>
        </div>
        <div class="contact-form reveal">
          <div class="form-group"><label class="form-label">Name</label><input type="text" class="form-input" placeholder="Your name"></div>
          <div class="form-group"><label class="form-label">Email</label><input type="email" class="form-input" placeholder="you@company.com"></div>
          <div class="form-group"><label class="form-label">Business Name</label><input type="text" class="form-input" placeholder="Your business"></div>
          <div class="form-group"><label class="form-label">Service Interested In</label>
            <select class="form-input" style="cursor:pointer;">
              <option>Website Redesign</option>
              <option>AI Automation</option>
              <option>SEO & Performance</option>
              <option>CRM Integration</option>
              <option>Full Package</option>
              <option>Not Sure Yet</option>
            </select>
          </div>
          <div class="form-group"><label class="form-label">Message</label><textarea class="form-input" placeholder="Tell us about your project, goals, and timeline."></textarea></div>
          <button class="btn-primary" style="width:100%;">Send Message</button>
          <p style="font-size:0.8125rem;color:var(--text-muted);text-align:center;">This form is a placeholder. Connect your backend (Formspree, Netlify Forms, or custom API) to make it functional.</p>
        </div>
      </div>
    </section>
  </div>${renderFooter()}`;
}

// LEGAL PAGES
function renderPrivacy() {
  return `<div class="page active"><div class="legal-page">
    <h1>Privacy Policy</h1>
    <p class="last-updated">Last updated: ${new Date().toLocaleDateString('en-IN', {year:'numeric', month:'long', day:'numeric'})}</p>
    <p>ASCEND WORKS ("we", "our", or "us") is committed to protecting your privacy. This Privacy Policy explains how we collect, use, disclose, and safeguard your information when you visit our website.</p>
    <h2>Information We Collect</h2>
    <p>We may collect personal information that you voluntarily provide to us when you fill out a contact form, book a consultation, or communicate with us. This may include your name, email address, phone number, and business details.</p>
    <h2>How We Use Your Information</h2>
    <p>We use the information we collect to respond to your inquiries, provide our services, improve our website, and communicate with you about our offerings. We do not sell your personal information to third parties.</p>
    <h2>Cookies and Tracking</h2>
    <p>We may use cookies and similar tracking technologies to monitor activity on our website and store certain information. You can instruct your browser to refuse all cookies or to indicate when a cookie is being sent.</p>
    <h2>Data Security</h2>
    <p>We implement appropriate technical and organizational measures to protect your personal information. However, no method of transmission over the Internet is 100% secure.</p>
    <h2>Contact Us</h2>
    <p>If you have any questions about this Privacy Policy, please contact us at [your-email@ascendworks.in].</p>
  </div>${renderFooter()}`;
}

function renderTerms() {
  return `<div class="page active"><div class="legal-page">
    <h1>Terms of Service</h1>
    <p class="last-updated">Last updated: ${new Date().toLocaleDateString('en-IN', {year:'numeric', month:'long', day:'numeric'})}</p>
    <p>Please read these Terms of Service ("Terms") carefully before using the ASCEND WORKS website or engaging our services.</p>
    <h2>Services</h2>
    <p>ASCEND WORKS provides website design, development, AI automation, and digital marketing services. All projects are governed by individual Statements of Work (SOW) that detail scope, timeline, and payment terms.</p>
    <h2>Payments</h2>
    <p>Payment terms are specified in your SOW. Generally, we require a deposit to commence work, with the balance due upon project completion. Late payments may result in project delays.</p>
    <h2>Intellectual Property</h2>
    <p>Upon full payment, you own the final deliverables created specifically for your project. We retain the right to display the work in our portfolio unless otherwise agreed in writing.</p>
    <h2>Limitation of Liability</h2>
    <p>ASCEND WORKS shall not be liable for any indirect, incidental, special, consequential, or punitive damages resulting from your use of our services or website.</p>
    <h2>Governing Law</h2>
    <p>These Terms shall be governed by the laws of India. Any disputes shall be resolved in the courts of Mohali, Punjab.</p>
  </div>${renderFooter()}`;
}

function renderCookies() {
  return `<div class="page active"><div class="legal-page">
    <h1>Cookie Policy</h1>
    <p class="last-updated">Last updated: ${new Date().toLocaleDateString('en-IN', {year:'numeric', month:'long', day:'numeric'})}</p>
    <p>This Cookie Policy explains how ASCEND WORKS uses cookies and similar technologies on our website.</p>
    <h2>What Are Cookies</h2>
    <p>Cookies are small text files that are stored on your device when you visit a website. They help the website recognize your device and remember information about your visit.</p>
    <h2>How We Use Cookies</h2>
    <p>We use cookies to understand how visitors interact with our website, to improve user experience, and for analytics purposes. We do not use cookies to collect personally identifiable information.</p>
    <h2>Types of Cookies We Use</h2>
    <ul><li><strong>Essential cookies:</strong> Required for the website to function properly.</li><li><strong>Analytics cookies:</strong> Help us understand how visitors interact with our website.</li><li><strong>Preference cookies:</strong> Remember your settings and preferences.</li></ul>
    <h2>Managing Cookies</h2>
    <p>Most web browsers allow you to control cookies through their settings. You can usually find these settings in the "Options" or "Preferences" menu of your browser.</p>
    <h2>Contact</h2>
    <p>If you have any questions about our use of cookies, please contact us at [your-email@ascendworks.in].</p>
  </div>${renderFooter()}`;
}

// 404 PAGE
function render404() {
  return `<div class="page active"><div class="page-404">
    <div class="page-404-code">404</div>
    <h1 class="page-404-title">Page not found</h1>
    <p class="page-404-desc">The page you're looking for doesn't exist or has been moved.</p>
    <button class="btn-primary" onclick="navigateTo('home')">Back to Home</button>
  </div>${renderFooter()}`;
}

// ROUTES MAP
const routes = {
  home: renderHome, about: renderAbout, services: renderServices,
  portfolio: renderPortfolio, 'case-studies': renderCaseStudies,
  process: renderProcess, pricing: renderPricing, faq: renderFAQ,
  contact: renderContact, privacy: renderPrivacy, terms: renderTerms,
  cookies: renderCookies, 404: render404
};

// INIT
window.addEventListener('DOMContentLoaded', () => {
  const app = document.getElementById('app');
  app.innerHTML = renderNav() + routes.home();
  initNavScroll();
  initScrollReveal();
});
